import { Link, useLocation, useNavigate } from "react-router-dom";
import Logo from "./Logo";
import { scrollToSection } from "@/hooks/useScrollTo";

export default function Footer() {
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === "/";

  const handleSection = (id: string) => {
    if (isHome) scrollToSection(id);
    else {
      navigate("/");
      setTimeout(() => scrollToSection(id), 100);
    }
  };

  const sectionLabel: React.CSSProperties = {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: 10,
    letterSpacing: "0.18em",
    textTransform: "uppercase",
    color: "var(--low)",
    marginBottom: 20,
  };

  const linkStyle: React.CSSProperties = {
    fontFamily: "'Manrope', sans-serif",
    fontSize: 14,
    color: "var(--low)",
    background: "none",
    border: "none",
    padding: 0,
    cursor: "pointer",
    textDecoration: "none",
    textAlign: "left",
    transition: "color 0.15s",
  };

  const onHover = (e: React.MouseEvent<HTMLElement>) => {
    e.currentTarget.style.color = "var(--text)";
  };
  const onLeave = (e: React.MouseEvent<HTMLElement>) => {
    e.currentTarget.style.color = "var(--low)";
  };

  return (
    <footer
      style={{
        borderTop: "1px solid var(--border-c)",
        background: "var(--bg)",
        padding: "60px 0 40px",
      }}
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10">
        <div className="footer-grid" style={{ display: "grid", gap: 48, marginBottom: 48 }}>
          <div>
            <div style={{ marginBottom: 16 }}>
              <Logo />
            </div>
            <p
              style={{
                fontSize: 14,
                color: "var(--low)",
                maxWidth: 280,
                lineHeight: 1.65,
                marginBottom: 24,
              }}
            >
              Premium websites built fast and affordably. AI-powered speed,
              human craft — delivered in 14 days.
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
              <a
                href="mailto:hello@luxiflow.io"
                style={{ fontSize: 13, color: "var(--mid)", transition: "color 0.15s" }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "var(--text)")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "var(--mid)")}
              >
                hello@luxiflow.io
              </a>
              <a
                href="https://linkedin.com/company/luxiflow"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Luxiflow on LinkedIn"
                style={{ display: "inline-flex", color: "var(--low)", transition: "color 0.15s" }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "var(--text)")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "var(--low)")}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
              </a>
            </div>
          </div>

          <div>
            <p style={sectionLabel}>Navigation</p>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 12 }}>
              {(["services", "process", "pricing", "contact"] as const).map((id) => (
                <li key={id}>
                  <button
                    onClick={() => handleSection(id)}
                    style={linkStyle}
                    onMouseEnter={onHover}
                    onMouseLeave={onLeave}
                  >
                    {id.charAt(0).toUpperCase() + id.slice(1)}
                  </button>
                </li>
              ))}
              <li>
                <Link to="/blog" style={linkStyle} onMouseEnter={onHover} onMouseLeave={onLeave}>
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <p style={sectionLabel}>Legal</p>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 12 }}>
              {[
                ["Privacy Policy", "/privacy-policy"],
                ["Cookie Policy", "/cookie-policy"],
                ["Terms of Service", "/terms-of-service"],
              ].map(([label, href]) => (
                <li key={href}>
                  <Link to={href} style={linkStyle} onMouseEnter={onHover} onMouseLeave={onLeave}>
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div
          className="footer-bottom"
          style={{
            borderTop: "1px solid var(--border-c)",
            paddingTop: 24,
            display: "flex",
            justifyContent: "space-between",
            gap: 12,
            flexWrap: "wrap",
          }}
        >
          <p style={{ fontSize: 12, color: "var(--low)" }}>
            © {new Date().getFullYear()} Luxiflow. All rights reserved.
          </p>
          <p style={{ fontSize: 12, color: "var(--low)" }}>
            Built by Luxiflow — with precision.
          </p>
        </div>
      </div>

    </footer>
  );
}
