import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import flagIconsUrl from "flag-icons/css/flag-icons.min.css?url";

// Defer flag-icons CSS (~28KB + embedded SVGs) — not critical for first paint.
// Inject as a non-blocking stylesheet after initial render.
const loadFlagIcons = () => {
  if (document.querySelector(`link[data-flag-icons]`)) return;
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = flagIconsUrl;
  link.setAttribute("data-flag-icons", "");
  document.head.appendChild(link);
};
if (typeof window !== "undefined") {
  if ("requestIdleCallback" in window) {
    (window as any).requestIdleCallback(loadFlagIcons, { timeout: 2000 });
  } else {
    setTimeout(loadFlagIcons, 0);
  }
}

createRoot(document.getElementById("root")!).render(<App />);
