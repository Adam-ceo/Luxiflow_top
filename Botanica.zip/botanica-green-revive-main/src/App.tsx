import { lazy, Suspense, useEffect, useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import { languageOptions, type Lang } from "@/lib/translations";

const NotFound = lazy(() => import("./pages/NotFound.tsx"));

const STORAGE_KEY = "botanica-lang";
const SUPPORTED: Lang[] = languageOptions.map((o) => o.code);

const detectLang = (): Lang => {
  if (typeof window === "undefined") return "hu";
  try {
    const stored = localStorage.getItem(STORAGE_KEY) as Lang | null;
    if (stored && SUPPORTED.includes(stored)) return stored;
  } catch {}
  const candidates = (navigator.languages && navigator.languages.length
    ? navigator.languages
    : [navigator.language || "hu"]
  ).map((l) => l.toLowerCase().split("-")[0] as Lang);
  const match = candidates.find((c) => SUPPORTED.includes(c));
  return match ?? "hu";
};

const App = () => {
  const [lang, setLang] = useState<Lang>(detectLang);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch {}
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
    }
  }, [lang]);

  return (
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Suspense fallback={null}>
          <Routes>
            <Route path="/" element={<Index lang={lang} setLang={setLang} />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </TooltipProvider>
  );
};

export default App;
