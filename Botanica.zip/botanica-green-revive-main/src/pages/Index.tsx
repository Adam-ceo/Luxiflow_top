import { lazy, Suspense } from "react";
import { Navbar } from "@/components/botanica/Navbar";
import { Hero } from "@/components/botanica/Hero";
import { About } from "@/components/botanica/About";
import type { Lang } from "@/lib/translations";

const Services = lazy(() => import("@/components/botanica/Services").then(m => ({ default: m.Services })));
const Payments = lazy(() => import("@/components/botanica/Payments").then(m => ({ default: m.Payments })));
const OpeningHours = lazy(() => import("@/components/botanica/OpeningHours").then(m => ({ default: m.OpeningHours })));
const MapSection = lazy(() => import("@/components/botanica/MapSection").then(m => ({ default: m.MapSection })));
const ContactForm = lazy(() => import("@/components/botanica/ContactForm").then(m => ({ default: m.ContactForm })));
const Footer = lazy(() => import("@/components/botanica/Footer").then(m => ({ default: m.Footer })));

interface Props {
  lang: Lang;
  setLang: (l: Lang) => void;
}

const Index = ({ lang, setLang }: Props) => {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar lang={lang} setLang={setLang} />
      <main>
        <Hero lang={lang} />
        <About lang={lang} />
        <Suspense fallback={null}>
          <Services lang={lang} />
          <Payments lang={lang} />
          <OpeningHours lang={lang} />
          <MapSection lang={lang} />
          <ContactForm lang={lang} />
        </Suspense>
      </main>
      <Suspense fallback={null}>
        <Footer lang={lang} />
      </Suspense>
    </div>
  );
};

export default Index;
