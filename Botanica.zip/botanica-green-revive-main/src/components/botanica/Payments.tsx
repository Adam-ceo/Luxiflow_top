import { motion } from "framer-motion";
import { CreditCard, Banknote, Smartphone, Layers } from "lucide-react";
import { translations, type Lang } from "@/lib/translations";

export const Payments = ({ lang }: { lang: Lang }) => {
  const t = translations[lang];

  const items = [
    { icon: CreditCard, title: t.services.cardPayment, desc: t.services.cardPaymentDesc },
    { icon: Banknote, title: t.services.cash, desc: t.services.cashDesc },
    { icon: Smartphone, title: t.services.contactless, desc: t.services.contactlessDesc },
    { icon: Layers, title: t.services.szepCard, desc: t.services.szepCardDesc },
  ];

  return (
    <section
      id="fizetes"
      className="py-20 lg:py-28"
      style={{ backgroundColor: "#2C3E2D" }}
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p
            className="text-xs uppercase tracking-[0.25em] mb-3"
            style={{ color: "#C9D6C2" }}
          >
            {t.services.paymentLabel}
          </p>
          <h2
            className="font-serif-display text-4xl sm:text-5xl font-semibold mb-3"
            style={{ color: "#F5F0E8" }}
          >
            {t.services.paymentTitle}
          </h2>
          <p className="text-sm" style={{ color: "#C9D6C2" }}>
            {t.services.paymentSubtitle}
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {items.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.45, delay: (i % 4) * 0.06 }}
              className="rounded-2xl border p-5 sm:p-6 text-center"
              style={{
                backgroundColor: "rgba(255,255,255,0.07)",
                borderColor: "rgba(255,255,255,0.10)",
              }}
            >
              <div
                className="w-11 h-11 rounded-xl grid place-items-center mx-auto mb-4"
                style={{ backgroundColor: "rgba(245,240,232,0.10)" }}
              >
                <s.icon className="w-5 h-5" style={{ color: "#F5F0E8" }} />
              </div>
              <h3
                className="font-semibold text-base mb-1.5 font-serif-display"
                style={{ color: "#F5F0E8" }}
              >
                {s.title}
              </h3>
              <p className="text-sm" style={{ color: "#A8B8A2" }}>
                {s.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
