import { motion } from "framer-motion";
import { MapPin, Phone, Mail } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { translations, type Lang } from "@/lib/translations";

const MAP_SRC =
  "https://maps.google.com/maps?q=Botanica%20Caff%C3%A9%20%26%20Bar%2C%20Sz%C3%A9chenyi%20t%C3%A9r%207%2C%20Gy%C5%91r&z=17&output=embed";

export const MapSection = ({ lang }: { lang: Lang }) => {
  const t = translations[lang];
  const mapWrapRef = useRef<HTMLDivElement | null>(null);
  const [loadMap, setLoadMap] = useState(false);

  useEffect(() => {
    if (loadMap) return;
    const el = mapWrapRef.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setLoadMap(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setLoadMap(true);
          observer.disconnect();
        }
      },
      { rootMargin: "300px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [loadMap]);

  const details = [
    { icon: MapPin, label: t.map.addressLabel, value: "9022 Győr, Széchenyi tér 7." },
    { icon: Phone, label: t.map.phoneLabel, value: "+36 30 616 9960", href: "tel:+36306169960" },
    { icon: Mail, label: t.map.emailLabel, value: "botanica.caffe@gmail.com", href: "mailto:botanica.caffe@gmail.com" },
  ];

  return (
    <section
      id="elerhetoseg"
      className="py-20 lg:py-28"
      style={{ backgroundColor: "#EDE8DC" }}
    >
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-10 items-start">
          <motion.div
            initial={{ opacity: 0, x: -16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <p
              className="text-xs uppercase tracking-[0.25em] mb-3"
              style={{ color: "#3D5A3E" }}
            >
              {t.map.label}
            </p>
            <h2
              className="font-serif-display text-4xl sm:text-5xl font-semibold mb-8"
              style={{ color: "#1C1A16" }}
            >
              {t.map.title}
            </h2>

            <div className="flex flex-col gap-4">
              {details.map((d) => {
                const Tag: any = d.href ? "a" : "div";
                return (
                  <Tag
                    key={d.label}
                    href={d.href}
                    className="flex gap-4 items-start group"
                  >
                    <div
                      className="w-11 h-11 shrink-0 rounded-lg grid place-items-center border"
                      style={{ backgroundColor: "#EDE8DC", borderColor: "#D8D0C4" }}
                    >
                      <d.icon className="w-4 h-4" style={{ color: "#3D5A3E" }} />
                    </div>
                    <div>
                      <p
                        className="text-xs uppercase tracking-widest mb-1"
                        style={{ color: "#6B6560" }}
                      >
                        {d.label}
                      </p>
                      <p
                        className="font-medium transition-colors group-hover:underline"
                        style={{ color: "#1C1A16" }}
                      >
                        {d.value}
                      </p>
                    </div>
                  </Tag>
                );
              })}
            </div>
          </motion.div>

          <motion.div
            ref={mapWrapRef}
            initial={{ opacity: 0, x: 16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="rounded-xl overflow-hidden border"
            style={{ borderColor: "#D8D0C4", height: 380 }}
          >
            {loadMap && (
              <iframe
                title="Botanica Caffé & Bar map"
                src={MAP_SRC}
                className="w-full h-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};
