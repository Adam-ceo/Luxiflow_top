import { motion } from "framer-motion";
import { Coffee, Wifi, Sun, ParkingSquare, Heart, Cigarette } from "lucide-react";
import { translations, type Lang } from "@/lib/translations";

const renderWithAmp = (text: string) =>
  text.split(/(&)/).map((part, i) =>
    part === "&" ? (
      <span
        key={i}
        style={{ fontFamily: "'Helvetica Neue', Arial, sans-serif", fontWeight: 400 }}
      >
        &amp;
      </span>
    ) : (
      <span key={i}>{part}</span>
    )
  );

export const Services = ({ lang }: { lang: Lang }) => {
  const t = translations[lang];

  const items = [
    { icon: Coffee, title: t.services.drinks, desc: t.services.drinksDesc },
    { icon: Wifi, title: t.services.wifi, desc: t.services.wifiDesc },
    { icon: Sun, title: t.services.terrace, desc: t.services.terraceDesc },
    { icon: ParkingSquare, title: t.services.parking, desc: t.services.parkingDesc },
    { icon: Heart, title: t.services.pets, desc: t.services.petsDesc },
    { icon: Cigarette, title: t.services.smoking, desc: t.services.smokingDesc },
  ];

  return (
    <section
      id="szolgaltatasok"
      className="py-20 lg:py-28"
      style={{ backgroundColor: "#F5F0E8" }}
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p
            className="text-xs uppercase tracking-[0.25em] mb-3"
            style={{ color: "#3D5A3E" }}
          >
            {t.services.label}
          </p>
          <h2
            className="font-serif-display text-4xl sm:text-5xl font-semibold"
            style={{ color: "#1C1A16" }}
          >
            {t.services.title}
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {items.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.45, delay: (i % 3) * 0.06 }}
              className="rounded-[10px] border p-[22px] text-center transition-colors hover:bg-[#E0D9CE]"
              style={{ backgroundColor: "#EDE8DC", borderColor: "#D8D0C4" }}
            >
              <div
                className="w-12 h-12 rounded-[10px] grid place-items-center mx-auto mb-4"
                style={{ backgroundColor: "#3D5A3E" }}
              >
                <s.icon className="w-5 h-5" style={{ color: "#F5F0E8" }} />
              </div>
              <h3
                className="font-semibold text-base mb-1.5 font-serif-display"
                style={{ color: "#1C1A16" }}
              >
                {renderWithAmp(s.title)}
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: "#6B6560" }}>
                {s.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
