import { motion } from "framer-motion";
import { Coffee, Car } from "lucide-react";
import { translations, type Lang } from "@/lib/translations";

export const About = ({ lang }: { lang: Lang }) => {
  const t = translations[lang];

  const cards = [
    { icon: Coffee, title: t.about.card1Title, text: t.about.card1Text },
    { icon: Car, title: t.about.card2Title, text: t.about.card2Text },
  ];

  return (
    <section id="rolunk" className="py-20 lg:py-28" style={{ backgroundColor: "#EDE8DC" }}>
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p
            className="text-xs uppercase tracking-[0.25em] mb-3"
            style={{ color: "#3D5A3E" }}
          >
            {t.about.label}
          </p>
          <h2
            className="font-serif-display text-4xl sm:text-5xl font-semibold"
            style={{ color: "#1C1A16" }}
          >
            {t.about.title}
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-px" style={{ backgroundColor: "#D8D0C4" }}>
          {cards.map((c, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="p-8 lg:p-10"
              style={{ backgroundColor: "#EDE8DC" }}
            >
              <div
                className="w-12 h-12 rounded-lg grid place-items-center mb-5"
                style={{ backgroundColor: "#3D5A3E" }}
              >
                <c.icon className="w-5 h-5" style={{ color: "#F5F0E8" }} />
              </div>
              <h3
                className="font-serif-display text-2xl font-semibold mb-3"
                style={{ color: "#1C1A16" }}
              >
                {c.title}
              </h3>
              <p className="text-[15px] leading-relaxed" style={{ color: "#6B6560" }}>
                {c.text}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
