import { useState } from "react";
import { motion } from "framer-motion";
import { Send } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { translations, type Lang } from "@/lib/translations";

const MAX = 500;

export const ContactForm = ({ lang }: { lang: Lang }) => {
  const t = translations[lang];
  const [msg, setMsg] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: t.contact.send + " ✓",
      description: t.contact.subtitle,
    });
    (e.target as HTMLFormElement).reset();
    setMsg("");
  };

  const fieldStyle: React.CSSProperties = {
    backgroundColor: "#F5F0E8",
    borderColor: "#D8D0C4",
    color: "#1C1A16",
  };

  return (
    <section id="kapcsolat" className="py-20 lg:py-28" style={{ backgroundColor: "#F5F0E8" }}>
      <div className="container max-w-2xl">
        <div className="text-center mb-10">
          <p
            className="text-xs uppercase tracking-[0.25em] mb-3"
            style={{ color: "#3D5A3E" }}
          >
            {t.contact.label}
          </p>
          <h2
            className="font-serif-display text-4xl sm:text-5xl font-semibold mb-4"
            style={{ color: "#1C1A16" }}
          >
            {t.contact.title}
          </h2>
          <p style={{ color: "#6B6560" }}>{t.contact.subtitle}</p>
        </div>

        <motion.form
          onSubmit={onSubmit}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="rounded-xl border p-8 space-y-5"
          style={{ backgroundColor: "#EDE8DC", borderColor: "#D8D0C4" }}
        >
          <div className="grid md:grid-cols-2 gap-5">
            <Field name="name" label={t.contact.name} placeholder={t.contact.name} required style={fieldStyle} />
            <Field name="email" label={t.contact.email} placeholder={t.contact.email} type="email" required style={fieldStyle} />
          </div>
          <div className="grid md:grid-cols-2 gap-5">
            <Field name="phone" label={t.contact.phone} placeholder={t.contact.phone} type="tel" style={fieldStyle} />
            <Field name="subject" label={t.contact.subject} placeholder={t.contact.subject} required style={fieldStyle} />
          </div>

          <div>
            <label
              htmlFor="contact-message"
              className="block text-xs uppercase tracking-widest mb-2"
              style={{ color: "#6B6560" }}
            >
              {t.contact.message}
            </label>
            <textarea
              id="contact-message"
              name="message"
              aria-label={t.contact.message}
              required
              maxLength={MAX}
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              rows={5}
              className="w-full rounded-lg border px-4 py-3 text-sm focus:outline-none focus:border-[#3D5A3E] transition resize-none"
              style={fieldStyle}
            />
            <div className="mt-2 text-right text-xs" style={{ color: "#6B6560" }}>
              {msg.length} {t.contact.charCount}
            </div>
          </div>

          <button
            type="submit"
            className="w-full inline-flex items-center justify-center gap-2 font-medium px-6 h-12 rounded-lg transition-opacity hover:opacity-90"
            style={{ backgroundColor: "#3D5A3E", color: "#F5F0E8" }}
          >
            {t.contact.send}
            <Send className="w-4 h-4" />
          </button>
        </motion.form>
      </div>
    </section>
  );
};

const Field = ({
  label,
  name,
  type = "text",
  required,
  style,
  placeholder,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  style: React.CSSProperties;
  placeholder?: string;
}) => (
  <div>
    <label
      htmlFor={`contact-${name}`}
      className="block text-xs uppercase tracking-widest mb-2"
      style={{ color: "#6B6560" }}
    >
      {label}
    </label>
    <input
      id={`contact-${name}`}
      name={name}
      type={type}
      required={required}
      placeholder={placeholder}
      aria-label={label}
      className="w-full h-11 rounded-lg border px-4 text-sm focus:outline-none focus:border-[#3D5A3E] transition"
      style={style}
    />
  </div>
);
