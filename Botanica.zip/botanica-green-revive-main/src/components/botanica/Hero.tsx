import { motion } from "framer-motion";
import { MapPin, ArrowRight } from "lucide-react";
import { translations, type Lang } from "@/lib/translations";

export const Hero = ({ lang }: { lang: Lang }) => {
  const t = translations[lang];

  const leafPattern = `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160' viewBox='0 0 160 160'><g fill='none' stroke='%233D5A3E' stroke-width='1.2' stroke-linecap='round'><path d='M30 40c10-15 30-15 40 0-10 8-30 8-40 0z'/><path d='M50 40v15'/><path d='M110 90c-12-12-12-30 0-40 12 10 12 28 0 40z'/><path d='M110 90v18'/><path d='M40 110c8-10 24-10 32 0-8 8-24 8-32 0z'/></g></svg>`;

  return (
    <section
      id="cim"
      className="relative overflow-hidden"
      style={{ backgroundColor: "#F5F0E8" }}
    >
      <div
        aria-hidden
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `url("${leafPattern}")`,
          backgroundRepeat: "repeat",
          opacity: 0.04,
        }}
      />
      <div className="container relative z-10 pt-16 lg:pt-24 pb-10 lg:pb-12">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs mb-6 border"
              style={{
                backgroundColor: "#EDE8DC",
                borderColor: "#D8D0C4",
                color: "#3D5A3E",
              }}
            >
              <MapPin className="w-3.5 h-3.5" />
              {t.hero.badge}
            </div>

            <h1
              className="font-serif-display font-semibold leading-[1.05] tracking-tight"
              style={{ color: "#1C1A16", fontSize: "clamp(2.5rem, 5vw, 3.25rem)" }}
            >
              {t.hero.title.split("\n").map((line, i) => (
                <span key={i} className="block">
                  {line.split(/(&)/).map((part, j) =>
                    part === "&" ? (
                      <span
                        key={j}
                        style={{ fontFamily: "'Helvetica Neue', Arial, sans-serif", fontWeight: 400 }}
                      >
                        &amp;
                      </span>
                    ) : (
                      <span key={j}>{part}</span>
                    )
                  )}
                </span>
              ))}
            </h1>

            <p
              className="mt-5 text-xl italic font-serif-display"
              style={{ color: "#3D5A3E" }}
            >
              {t.hero.tagline}
            </p>

            <p
              className="mt-5 max-w-lg text-base leading-relaxed"
              style={{ color: "#6B6560" }}
            >
              {t.hero.desc}
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a
                href="#elerhetoseg"
                className="inline-flex items-center gap-2 px-6 h-12 rounded-lg text-sm font-medium transition-opacity hover:opacity-90"
                style={{ backgroundColor: "#3D5A3E", color: "#F5F0E8" }}
              >
                {t.hero.btnContact}
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#szolgaltatasok"
                className="inline-flex items-center gap-2 px-6 h-12 rounded-lg text-sm font-medium border transition-colors hover:bg-[#EDE8DC]"
                style={{ borderColor: "#3D5A3E", color: "#3D5A3E" }}
              >
                {t.hero.btnServices}
              </a>
            </div>
          </motion.div>

          {/* Right */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="relative rounded-2xl overflow-hidden border shadow-sm aspect-[4/3] lg:aspect-auto lg:h-[420px]"
            style={{ borderColor: "#D8D0C4" }}
          >
            <img
              src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=440&q=60&fm=webp&auto=format"
              srcSet="https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=440&q=60&fm=webp&auto=format 440w, https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=880&q=60&fm=webp&auto=format 880w, https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=1240&q=65&fm=webp&auto=format 1240w"
              sizes="(min-width: 1024px) 610px, 100vw"
              alt="Botanica Caffé interior"
              width={620}
              height={420}
              loading="eager"
              fetchPriority="high"
              className="w-full h-full object-cover"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};
