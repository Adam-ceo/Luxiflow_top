import { motion } from "framer-motion";
import { translations, type Lang } from "@/lib/translations";

export const OpeningHours = ({ lang }: { lang: Lang }) => {
  const t = translations[lang];

  const rows = [
    { day: t.openingHours.monTue, time: t.openingHours.closed, muted: true },
    { day: t.openingHours.wedThu, time: t.openingHours.wedThuTime },
    { day: t.openingHours.friSat, time: t.openingHours.friSatTime },
    { day: t.openingHours.sun, time: t.openingHours.closed, muted: true },
  ];

  return (
    <section className="py-20 lg:py-28" style={{ backgroundColor: "#3D5A3E" }}>
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p
            className="text-xs uppercase tracking-[0.25em] mb-3"
            style={{ color: "#D4E6D4" }}
          >
            {t.openingHours.label}
          </p>
          <h2
            className="font-serif-display text-4xl sm:text-5xl font-semibold"
            style={{ color: "#F5F0E8" }}
          >
            {t.openingHours.title}
          </h2>
        </div>

        <div className="max-w-3xl mx-auto grid sm:grid-cols-2 gap-px" style={{ backgroundColor: "rgba(245,240,232,0.15)" }}>
          {rows.map((r, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="flex items-center justify-between px-6 py-5"
              style={{ backgroundColor: "#3D5A3E" }}
            >
              <span className="text-sm" style={{ color: "rgba(245,240,232,0.7)" }}>
                {r.day}
              </span>
              <span
                className="font-medium"
                style={{ color: r.muted ? "rgba(245,240,232,0.4)" : "#F5F0E8" }}
              >
                {r.time}
              </span>
            </motion.div>
          ))}
        </div>

        <p
          className="text-center mt-10 italic text-sm max-w-xl mx-auto"
          style={{ color: "rgba(245,240,232,0.88)" }}
        >
          {t.openingHours.note}
        </p>
      </div>
    </section>
  );
};
