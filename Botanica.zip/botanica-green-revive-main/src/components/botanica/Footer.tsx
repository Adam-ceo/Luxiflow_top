import { Facebook, Instagram } from "lucide-react";
import { translations, type Lang } from "@/lib/translations";
import logoLightUrl from "@/assets/botanica-logo-light.webp";

export const Footer = ({ lang }: { lang: Lang }) => {
  const t = translations[lang];

  const navItems = [
    { href: "#cim", label: t.nav.home },
    { href: "#rolunk", label: t.nav.about },
    { href: "#szolgaltatasok", label: t.nav.services },
    { href: "#fizetes", label: t.nav.payment },
    { href: "#kapcsolat", label: t.nav.contact },
  ];

  const legalItems = [
    { label: t.footer.imprint },
    { label: t.footer.privacy },
    { label: t.footer.cookies },
  ];

  return (
    <footer style={{ backgroundColor: "#2C3E2D", color: "#EDE8DC" }}>
      <div className="container py-14">
        <div className="grid md:grid-cols-3 gap-10">
          <div>
            <div className="flex items-center gap-0 mb-4">
              <img
                src={logoLightUrl}
                alt="Botanica Caffé & Bar"
                width={128}
                height={128}
                className="h-14 w-auto object-contain -mr-3"
                style={{ maxWidth: "60px" }}
              />
              <span className="font-serif-display text-2xl font-semibold">Botanica</span>
            </div>
            <p className="text-sm mb-5" style={{ color: "rgba(237,232,220,0.65)" }}>
              {t.footer.tagline}
            </p>
            <div className="flex items-center gap-2">
              <a
                href="https://www.facebook.com/Botanicacaffe"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
                className="w-10 h-10 inline-grid place-items-center rounded-full border transition-colors hover:bg-white/5"
                style={{ borderColor: "rgba(237,232,220,0.2)" }}
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://www.instagram.com/botanica.caffe"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="w-10 h-10 inline-grid place-items-center rounded-full border transition-colors hover:bg-white/5"
                style={{ borderColor: "rgba(237,232,220,0.2)" }}
              >
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h3
              className="text-xs uppercase tracking-[0.2em] mb-4 font-serif-display"
              style={{ color: "rgba(237,232,220,0.85)" }}
            >
              {t.footer.nav}
            </h3>
            <ul className="space-y-2.5">
              {navItems.map((n) => (
                <li key={n.label}>
                  <a href={n.href} className="text-sm hover:underline" style={{ color: "#EDE8DC" }}>
                    {n.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3
              className="text-xs uppercase tracking-[0.2em] mb-4 font-serif-display"
              style={{ color: "rgba(237,232,220,0.85)" }}
            >
              {t.footer.legal}
            </h3>
            <ul className="space-y-2.5">
              {legalItems.map((l) => (
                <li key={l.label}>
                  <a href="#" className="text-sm hover:underline" style={{ color: "#EDE8DC" }}>
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div
          className="mt-12 pt-6 border-t flex justify-center items-center text-xs"
          style={{ borderColor: "rgba(237,232,220,0.1)", color: "rgba(237,232,220,0.85)" }}
        >
          <span>© 2026 Botanica Caffé & Bar</span>
        </div>
      </div>
    </footer>
  );
};
