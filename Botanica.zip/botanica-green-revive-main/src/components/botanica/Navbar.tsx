import { useEffect, useRef, useState } from "react";
import { Facebook, Instagram, Menu, X, ChevronDown } from "lucide-react";
import { translations, languageOptions, type Lang } from "@/lib/translations";
import logoUrl from "@/assets/botanica-logo.webp";

interface Props {
  lang: Lang;
  setLang: (l: Lang) => void;
}

export const Navbar = ({ lang, setLang }: Props) => {
  const t = translations[lang];
  const [open, setOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const desktopLangRef = useRef<HTMLDivElement>(null);
  const mobileLangRef = useRef<HTMLDivElement>(null);

  const links = [
    { href: "#cim", label: t.nav.home },
    { href: "#rolunk", label: t.nav.about },
    { href: "#szolgaltatasok", label: t.nav.services },
    { href: "#fizetes", label: t.nav.payment },
    { href: "#kapcsolat", label: t.nav.contact },
  ];

  const current = languageOptions.find((l) => l.code === lang)!;

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      const target = e.target as Node;
      const inDesktop = desktopLangRef.current?.contains(target);
      const inMobile = mobileLangRef.current?.contains(target);
      if (!inDesktop && !inMobile) {
        setLangOpen(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <header
      className="sticky top-0 z-50 border-b"
      style={{ backgroundColor: "#F5F0E8", borderColor: "#D8D0C4" }}
    >
      <div className="container">
        <nav className="flex items-center justify-between h-[72px]">
          {/* Logo */}
          <a href="#" className="flex items-center gap-0" aria-label="Botanica Caffé & Bar — kezdőlap">
            <img
              src={logoUrl}
              alt="Botanica Caffé & Bar"
              width={128}
              height={128}
              className="h-14 w-auto object-contain -mr-3"
              style={{ maxWidth: "60px" }}
            />
            <span
              className="font-serif-display text-2xl font-semibold"
              style={{ color: "#3D5A3E" }}
            >
              Botanica
            </span>
          </a>

          {/* Center nav */}
          <ul className="hidden lg:flex items-center gap-8">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="text-sm transition-colors hover:opacity-80"
                  style={{ color: "#1C1A16" }}
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          {/* Right */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href="https://www.facebook.com/Botanicacaffe"
              target="_blank"
              rel="noreferrer"
              aria-label="Facebook"
              className="w-10 h-10 grid place-items-center rounded-full border transition-colors hover:bg-[#EDE8DC]"
              style={{ borderColor: "#D8D0C4" }}
            >
              <Facebook className="w-4 h-4" style={{ color: "#3D5A3E" }} />
            </a>

            <a
              href="https://www.instagram.com/botanica.caffe"
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram"
              className="w-10 h-10 grid place-items-center rounded-full border transition-colors hover:bg-[#EDE8DC]"
              style={{ borderColor: "#D8D0C4" }}
            >
              <Instagram className="w-4 h-4" style={{ color: "#3D5A3E" }} />
            </a>

            <div className="relative" ref={desktopLangRef}>
              <button
                onClick={() => setLangOpen((v) => !v)}
                className="flex items-center gap-2 px-3 h-10 rounded-full border text-sm transition-colors hover:bg-[#EDE8DC]"
                style={{ borderColor: "#D8D0C4", color: "#1C1A16" }}
              >
                <span className={`fi fi-${current.flag} rounded-sm`} style={{ width: 20, height: 15 }} />
                <span className="font-medium uppercase">{current.code}</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-60" />
              </button>
              {langOpen && (
                <div
                  className="absolute right-0 top-12 w-56 rounded-xl border shadow-lg overflow-hidden max-h-[420px] overflow-y-auto"
                  style={{ backgroundColor: "#F5F0E8", borderColor: "#D8D0C4" }}
                >
                  {languageOptions.map((opt) => (
                    <button
                      key={opt.code}
                      onClick={() => {
                        setLang(opt.code);
                        setLangOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm text-left transition-colors hover:bg-[#EDE8DC] ${
                        opt.code === lang ? "font-semibold" : ""
                      }`}
                      style={{ color: "#1C1A16" }}
                    >
                      <span className={`fi fi-${opt.flag} rounded-sm`} style={{ width: 20, height: 15 }} />
                      <span>{opt.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Mobile */}
          <div className="lg:hidden flex items-center gap-2">
            <div className="relative" ref={mobileLangRef}>
              <button
                onClick={() => setLangOpen((v) => !v)}
                className="flex items-center gap-1.5 px-3 h-10 rounded-full border text-sm"
                style={{ borderColor: "#D8D0C4" }}
              >
                <span className={`fi fi-${current.flag} rounded-sm`} style={{ width: 20, height: 15 }} />
                <span className="font-medium uppercase">{current.code}</span>
              </button>
              {langOpen && (
                <div
                  className="absolute right-0 top-12 w-52 rounded-xl border shadow-lg overflow-hidden max-h-[360px] overflow-y-auto z-50"
                  style={{ backgroundColor: "#F5F0E8", borderColor: "#D8D0C4" }}
                >
                  {languageOptions.map((opt) => (
                    <button
                      key={opt.code}
                      onClick={() => {
                        setLang(opt.code);
                        setLangOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm text-left hover:bg-[#EDE8DC] ${
                        opt.code === lang ? "font-semibold" : ""
                      }`}
                      style={{ color: "#1C1A16" }}
                    >
                      <span className={`fi fi-${opt.flag} rounded-sm`} style={{ width: 20, height: 15 }} />
                      <span>{opt.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <button
              onClick={() => setOpen((v) => !v)}
              className="w-10 h-10 grid place-items-center rounded-full border"
              style={{ borderColor: "#D8D0C4" }}
              aria-label="Menu"
            >
              {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </nav>

        {open && (
          <div
            className="lg:hidden py-4 border-t"
            style={{ borderColor: "#D8D0C4" }}
          >
            <ul className="flex flex-col gap-1">
              {links.map((l) => (
                <li key={l.href}>
                  <a
                    onClick={() => setOpen(false)}
                    href={l.href}
                    className="block py-2.5 text-base"
                    style={{ color: "#1C1A16" }}
                  >
                    {l.label}
                  </a>
                </li>
              ))}
              <li className="pt-3 mt-2 border-t" style={{ borderColor: "#D8D0C4" }}>
                <a
                  href="https://www.facebook.com/Botanicacaffe"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 py-2 text-sm"
                  style={{ color: "#3D5A3E" }}
                >
                  <Facebook className="w-4 h-4" /> Facebook
                </a>
                <a
                  href="https://www.instagram.com/botanica.caffe"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 py-2 text-sm ml-4"
                  style={{ color: "#3D5A3E" }}
                >
                  <Instagram className="w-4 h-4" /> Instagram
                </a>
              </li>
            </ul>
          </div>
        )}
      </div>
    </header>
  );
};
