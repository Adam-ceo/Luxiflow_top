

## Instagram ikon hozzáadása a Navbarhoz

A Footerben már megjelenik az Instagram ikon a Facebook mellett, de a felső navigációs sávban (Navbar) jelenleg csak a Facebook ikon látszik. Valószínűleg ezért nem látod — a fejlécbe is hozzáadjuk az Instagramot.

### Változtatás

**`src/components/botanica/Navbar.tsx`**
- Importba: `Instagram` ikon hozzáadása a `lucide-react`-ből (a `Facebook` mellé).
- **Desktop jobb oldal** (Facebook gomb után): új `<a>` link az Instagramra (`https://www.instagram.com/botanica.caffe`), ugyanazzal a stílussal mint a Facebook gomb (`w-10 h-10`, kerek border, hover-effekt, `#3D5A3E` zöld ikonszín).
- **Mobil menü** (alsó kinyitható lista, Facebook link alatt): új `<a>` link Instagram ikonnal és „Instagram" szöveggel, a Facebook link mintájára.

### Érintett fájlok
- `src/components/botanica/Navbar.tsx` (1 import + 2 új link blokk)

